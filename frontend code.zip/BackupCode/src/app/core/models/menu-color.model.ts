export class MenuColorMenuModel {
    public tenantColor: string;
    public tenantName: string;
}