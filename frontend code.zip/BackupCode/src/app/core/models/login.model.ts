export class CreateLoginRequest {
  public email: string;
  public password: string;
  public rememeberme?: boolean;
}
