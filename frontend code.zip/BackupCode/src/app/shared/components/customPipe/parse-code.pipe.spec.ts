import { ParseCodePipe } from './parse-code.pipe';

describe('ParseCodePipe', () => {
  it('create an instance', () => {
    const pipe = new ParseCodePipe();
    expect(pipe).toBeTruthy();
  });
});
