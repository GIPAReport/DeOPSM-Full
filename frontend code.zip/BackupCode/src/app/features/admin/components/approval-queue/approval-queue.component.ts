import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ApprovalQueueModel } from 'src/app/core/models/approval-queue.model';
import { LoginService } from 'src/app/features/auth/services/login/login.service';
import { ApprovalQueueService } from '../../services/approval-queue.service';

@Component({
  selector: 'app-approval-queue',
  templateUrl: './approval-queue.component.html',
  styleUrls: ['./approval-queue.component.css'],
})
export class ApprovalQueueComponent implements OnInit {
  approvalQueueList: ApprovalQueueModel[];
  userId: number;

  constructor(
    private loginService: LoginService,
    private approvalQueueService: ApprovalQueueService
  ) {}

  ngOnInit(): void {
    this.getuserId();
    this.getApprovalQueue();
  }

  getuserId() {
    this.loginService.authentication$.subscribe((approvalQueue) => {
      this.userId = approvalQueue[0].userId;
    });
  }

  getApprovalQueue() {
    this.approvalQueueService.getuserId(this.userId).subscribe(
      (approvalQueue: ApprovalQueueModel[]) => {
        this.approvalQueueList = approvalQueue;
      },
      (error: HttpErrorResponse) => {
        throw new Error(error.error.message);
      }
    );
  }
}
