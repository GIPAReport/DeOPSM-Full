package com.designops.utility;

import com.designops.exception. SequenceException;
public interface HostingBo {
void save(String name) throws SequenceException;
}
