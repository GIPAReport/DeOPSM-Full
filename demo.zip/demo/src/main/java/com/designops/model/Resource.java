package com.designops.model;

import java.util.List;

public class Resource {

	private List<Resource2> resources;

	public List<Resource2> getResources() {
		return resources;
	}

	public void setResources(List<Resource2> resources) {
		this.resources = resources;
	}
	
	
}
