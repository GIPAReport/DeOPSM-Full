package com.designops.model;

public class RichTextArray {
	
	private String blockTiitle;
	
	private String richText;

	public String getBlockTiitle() {
		return blockTiitle;
	}

	public void setBlockTiitle(String blockTiitle) {
		this.blockTiitle = blockTiitle;
	}

	public String getRichText() {
		return richText;
	}

	public void setRichText(String richText) {
		this.richText = richText;
	}
	
	
	

}
