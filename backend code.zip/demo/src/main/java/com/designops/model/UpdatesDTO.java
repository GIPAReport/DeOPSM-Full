package com.designops.model;

public class UpdatesDTO {

}
